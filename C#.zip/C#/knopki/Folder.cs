
using System;
using System.ComponentModel.DataAnnotations;

namespace knopki;

public class Folder 
{
    [Required]
    public string Parent { get; set; }
    [Required]
    public string Child { get; set; }
}
