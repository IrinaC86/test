﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Ascon.Polynom.Api;
using Ascon.Polynom.Login;

namespace knopki;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
        private static readonly Dictionary<string, IConcept> ConceptsDictionary = new Dictionary<string, IConcept>();
        private const string Concept1Name = "Понятие";
        private const string Concept1Code = "conceptCode";
        private const string SubConcept1Name = "СубПонятие";
        private const string SubConcept1Code = "subConceptCode";
        private const string PropDefGroup = "Папка моих описаний свойств";
        private const string StringPropDefName = "Строка";
        private const string StringPropDefCode = "StringPropDefCode";

        private const string ReferenceName = "Мой справочник";
        private const string CatalogName = "Мой каталог";
        private const string GroupName = "Моя группа";

        private const string ElementName = "Мой объект";
        private const string ElementValue = "Значение свойства";

    public MainWindow()
    {
        InitializeComponent();
    }

            private void Button_Click(object sender, RoutedEventArgs e)
        {

                Spire.Xls.Workbook workbook = new Spire.Xls.Workbook();
                workbook.LoadFromFile(@"C:\Users\isergeeva\Desktop\C#\folder.xlsx");
                Spire.Xls.Worksheet worksheet=workbook.Worksheets[0];

                List<Folder> ListFolder= new List<Folder>();
                List<Folder> NewListFolder= new List<Folder>();
                MessageBox.Show(Convert.ToString(worksheet.Rows.Count()));

                for (int i=1; i<=worksheet.Rows.Count(); i++)
                {
                   Folder ObjectFolder= new Folder();
                   ObjectFolder.Parent=worksheet.Range[i,1].Value;
                   ObjectFolder.Child=worksheet.Range[i,2].Value;
                   ListFolder.Add(ObjectFolder);
                }

                for (int i=0; i<ListFolder.Count(); i++)
                {
                    if(ListFolder[i].Parent=="NULL")
                    {
                       NewListFolder.Add(ListFolder[i]);
                       ListFolder.Remove(ListFolder[i]);
                       i=i-1;
                    }
                }
                

          while(ListFolder.Count()>0)
          {
                for (int i=0; i<NewListFolder.Count(); i++)
                {
                    for (int j=0; j<ListFolder.Count(); j++)
                    {
                        if(NewListFolder[i].Child==ListFolder[j].Parent)
                        {
                         NewListFolder.Add(ListFolder[j]);
                         ListFolder.Remove(ListFolder[j]);
                         j=j-1;
                        }
                    }
                }

          }

            int icount=0;

            ISession session;
            if (LoginManager.TryOpenSession(Guid.Empty, out session))
            {
                using (session)
                {
                    session.ClientType = ClientType.Editor;

                    var transaction = session.Objects.StartTransaction();
                    try
                    {
                          var references = session.Objects.AllReferences;
                          foreach (var reference in references)
                            {
                                if(reference.Name=="Новый справочник")
                                {


                                    var catalog = reference.Catalogs.FirstOrDefault(c => c.Name == "Прочие изделия");
                                    if (catalog != null)
                                    {
                                        for (int i=0; i<NewListFolder.Count(); i++)
                                        {
                                            if(NewListFolder[i].Parent=="NULL")
                                            {
                                               var group = catalog.CreateGroup(NewListFolder[i].Child); 
                                               NewListFolder.Remove(NewListFolder[i]);
                                               i=i-1;
                                               icount=icount+1;
                                            }
                                            else
                                            {
                                                var group1 = catalog.Groups.FirstOrDefault(g => g.Name == NewListFolder[i].Parent);
                                                if (group1 != null)
                                                {
                                                    IGroup group2 = group1.CreateGroup(NewListFolder[i].Child); 
                                                    NewListFolder.Remove(NewListFolder[i]);
                                                    i=i-1;
                                                    icount=icount+1;
                                                    icount=AddGroup(group2, NewListFolder, icount);
                                                }
                                            }
                                        }


                                    }

                                }
                            }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                    MessageBox.Show(ex.ToString());
                    }
                }
            }
            else MessageBox.Show("Не удалось создать сессию");

            MessageBox.Show("Создание папок завершилось успешно. Количество: "+Convert.ToString(icount));




        }

    public int AddGroup(IGroup group2, List<Folder> NewListFolder, int icount)
    {
        for (int i=0; i<NewListFolder.Count(); i++)
        {
            if(group2.Name==NewListFolder[i].Parent)
           {
             var group3 = group2.CreateGroup(NewListFolder[i].Child); 
             NewListFolder.Remove(NewListFolder[i]);
             i=i-1;
             icount=icount+1;
             icount=AddGroup(group3, NewListFolder, icount);
           }
        }

        return icount;
    }

        private void ButtonObject_Click(object sender, RoutedEventArgs e)
        {
            ISession session;
            if (LoginManager.TryOpenSession(Guid.Empty, out session))
            {
                using (session)
                {


                    var transaction = session.Objects.StartTransaction();
                    try
                    {
                            var reference = session.Objects.AllReferences.FirstOrDefault(r => r.Name == "Новый справочник");
                            if (reference != null)
                            {

                                    var catalog = reference.Catalogs.FirstOrDefault(c => c.Name == "Прочие изделия");
                                    if (catalog != null)
                                    {
                                       var group1 = catalog.Groups.FirstOrDefault(g => g.Name == "Выключатели");
                                       if (group1 != null)
                                       {
                                          var element = group1.Elements.FirstOrDefault(el => el.Name == "Концевой выключатель CLS-111 (рычаг с роликом нажимной)");
                                          if (element != null)
                                          {
                                          }
                                          else
                                          {

                                               element = group1.CreateElement("Концевой выключатель CLS-111 (рычаг с роликом нажимной)");

                                               foreach (var assignedConcept in element.RealizedContracts)
                                               {

                                               
                                               // Берем все свойства объекта (пришли унаследованные от группы), но только "легкие", без подписок, чтобы считать и задать значение. 
                                               var properties = element.GetProperties(PropertyCollectionOptions.OnlyPropertySources);
                                               foreach (var property in properties)
                                               {
                                                if(property.DisplayName=="Обозначение")
                                                {


                                                   var concept1=session.Objects.GetByCode<IConcept>(assignedConcept.Code);
                                                    if (property.Concept == concept1)	
		                                             {

                                                     IStringPropertyDefinition propDef = (IStringPropertyDefinition)property.Definition;

                                                    IStringPropertyValueData vd= propDef.CreateStringPropertyValueData(Convert.ToString("Концевой выключатель CLS-111 (рычаг с роликом нажимной)"));
                                                    // propDef.AssignStringPropertyValue(element, concept1, vd);

                                                    }   
                                                   

                                                 }
                                               }
                                               }
                                          }

                                       }
                                    }


                            }

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                    MessageBox.Show(ex.ToString());
                    }
                }
            }
            else MessageBox.Show("Не удалось создать сессию");

            MessageBox.Show("Создание объектов завершилось успешно. Количество: ");

        }

        private void ButtonObjectSDK_Click(object sender, RoutedEventArgs e)
        {
            ISession session;
            if (LoginManager.TryOpenSession(Guid.Empty, out session))
            {
                using (session)
                {

                Console.WriteLine($"Сессия \"{session.Id}\" успешно получена.");
                CreateMetadata(session);
                session.Close();
                }
            }
            else
            {
                MessageBox.Show("Не удалось получить сессию");
            }

        }
        


        private static void CreateMetadata(ISession session)
        {
            var transaction = session.Objects.StartTransaction();
            try
            {
                #region Создание понятий, описаний свойств и свойств-понятий

                var concept1 = EnsureConcept(session, Concept1Code, Concept1Name, null);
                EnsureConcept(session, SubConcept1Code, SubConcept1Name, concept1);

                var propDefGroup = session.Objects.PropDefCatalog.PropDefGroups.FirstOrDefault(g => g.Name == PropDefGroup) ??
                                   session.Objects.PropDefCatalog.CreatePropDefGroup(PropDefGroup);

                var stringPropDef = propDefGroup.PropertyDefinitions.FirstOrDefault(p => p.Code == StringPropDefCode) ??
                                    propDefGroup.CreateStringPropertyDefinition(StringPropDefName, StringPropDefCode);

              //  var ps = concept1.CreatePropertySource(stringPropDef);
            //    var options = ps.GetConceptPropertySource(concept1);
              //  if (options != null)
              //  {
              //      if (options.IsMandatoryEnabled)
              //      {
              //          options.IsMandatory = true;
              //      }
             //   }

                #endregion

                var reference = session.Objects.AllReferences.FirstOrDefault(r => r.Name == ReferenceName) ??
                                session.Objects.CreateReference(ReferenceName);

                var catalog = reference.Catalogs.FirstOrDefault(c => c.Name == CatalogName) ??
                              reference.CreateCatalog(CatalogName);

                var group = catalog.Groups.FirstOrDefault(g => g.Name == GroupName) ??
                            catalog.CreateGroup(GroupName);

                var appointedConcept = group.AddAppointedConcept(concept1);
                appointedConcept.IsInheritable = true;

                Console.WriteLine("Создание метаданных завершено.");

                #region Создание объекта и значения свойства

                var element = group.CreateElement(ElementName);
                
                // Берем все свойства объекта (пришли унаследованные от группы), но только "легкие", без подписок, чтобы считать и задать значение. 
                var properties = element.GetProperties(PropertyCollectionOptions.OnlyPropertySources);
                foreach (var property in properties)
                {
                    if (property.Contract == concept1)
                    {
                        var propDef = (IStringPropertyDefinition)property.Definition;
                        propDef.AssignStringPropertyValue(element, concept1, propDef.CreateStringPropertyValueData(ElementValue));
                    }
                }

                #endregion

                Console.WriteLine("Создание объекта завершено.");
                transaction.Commit();
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                Console.WriteLine("Произошла ошибка " + ex.Message);
            }
        }
        
    
        private static IConcept EnsureConcept(ISession session, string code, string name, IConcept superConcept)
        {
            if (!ConceptsDictionary.TryGetValue(code, out var concept))
            {
                if (superConcept == null)
                {
                    concept = session.Objects.GetByCode<IConcept>(code) ?? session.Objects.CreateConcept(name, code);
                }
                else
                {
                    concept = superConcept.SubConcepts.FirstOrDefault(c => c.Code == code) ??
                              superConcept.CreateSubConcept(name, code);
                }

                ConceptsDictionary.Add(code, concept);
            }

            return concept;
        }
}